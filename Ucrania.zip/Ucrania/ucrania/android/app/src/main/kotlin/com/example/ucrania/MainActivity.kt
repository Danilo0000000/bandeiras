package com.example.ucrania

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
